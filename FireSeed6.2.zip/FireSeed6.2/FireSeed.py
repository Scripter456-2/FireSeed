#!/usr/bin/env python3
"""
FireSeed 6.2 (Enhanced) — PyQt5 Chromium-based browser with Advanced Plugin System
Features: tabs, custom homepage buttons, split-screen panel, advanced plugins with permissions,
          in-browser code editor, bookmarks, session restore, history, dev console, downloads,
          user CSS, modern HTML5/CSS3/ES6+ support
All data saved in same folder as script for portability
Requires: PyQt5, PyQtWebEngine
"""

import sys
import os
import json
import typing
import importlib.util
from pathlib import Path
from urllib.parse import urlparse, quote_plus
from datetime import datetime

from PyQt5.QtCore import QUrl, Qt, QSize, QFileInfo, pyqtSignal, QObject
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QLineEdit, QToolBar, QAction, QTabWidget, QWidget,
    QVBoxLayout, QTextEdit, QDockWidget, QPushButton, QLabel, QHBoxLayout,
    QListWidget, QListWidgetItem, QMessageBox, QFileDialog, QMenu, QDialog,
    QSplitter, QFrame, QScrollArea, QGridLayout, QInputDialog, QComboBox,
    QCheckBox, QShortcut
)
from PyQt5.QtGui import QIcon, QFont, QKeySequence, QTextCursor, QColor, QSyntaxHighlighter, QTextCharFormat
from PyQt5.QtWebEngineWidgets import (
    QWebEngineView, QWebEngineProfile, QWebEngineScript, QWebEngineDownloadItem,
    QWebEngineSettings
)

# ---------- Configuration / Storage ----------
APP_NAME = "FireSeed6.2"
APP_VERSION = "6.2 (Enhanced)"

# Save all data in same directory as script file
SCRIPT_DIR = Path(__file__).parent.resolve()
DATA_DIR = SCRIPT_DIR / "fireseed_data"
DATA_DIR.mkdir(parents=True, exist_ok=True)

# Create subdirectories
PLUGINS_DIR = DATA_DIR / "plugins"
PLUGINS_DIR.mkdir(parents=True, exist_ok=True)

HISTORY_DIR = DATA_DIR / "history"
HISTORY_DIR.mkdir(parents=True, exist_ok=True)

DOWNLOADS_DIR = DATA_DIR / "downloads"
DOWNLOADS_DIR.mkdir(parents=True, exist_ok=True)

# Data files
BOOKMARKS_FILE = DATA_DIR / "bookmarks.json"
SESSION_FILE = DATA_DIR / "session.json"
USERCSS_FILE = DATA_DIR / "userstyle.css"
BUTTONS_FILE = DATA_DIR / "custom_buttons.json"
PLUGINS_CONFIG = DATA_DIR / "plugins_config.json"
HISTORY_FILE = DATA_DIR / "history.json"
SETTINGS_FILE = DATA_DIR / "settings.json"
PERMISSIONS_FILE = DATA_DIR / "plugin_permissions.json"

DEFAULT_USER_CSS = """
:root { color-scheme: light; }
html, body { background-color: #ffffff !important; color: #000000 !important; }
img { max-width: 100%; height: auto; }
"""

# Default custom buttons configuration
DEFAULT_BUTTONS = [
    {"title": "YouTube", "type": "url", "value": "https://www.youtube.com"},
    {"title": "Google", "type": "url", "value": "https://www.google.com"},
    {"title": "GitHub", "type": "url", "value": "https://github.com"},
    {"title": "Remove Ads", "type": "js", "value": "document.querySelectorAll('[class*=ad],[id*=ad]').forEach(el=>el.remove())"},
    {"title": "Animate", "type": "js", "value": "document.body.style.animation='spin 4s infinite';document.styleSheets[0].insertRule('@keyframes spin{to{transform:rotate(360deg)}}',0)"}
]

HOMEPAGE_HTML = """<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>FireSeed 6.2 (Enhanced)</title>
<style>
* { margin: 0; padding: 0; box-sizing: border-box; }
body {
    font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
    background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
    color: #ffffff;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    min-height: 100vh;
    padding: 20px;
}
.container { max-width: 800px; width: 100%; }
h1 {
    font-weight: 300;
    font-size: 3.5rem;
    margin-bottom: 0.5rem;
    color: #ffffff;
    text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
    text-align: center;
}
.version {
    text-align: center;
    color: #ffffff;
    font-size: 0.9rem;
    margin-bottom: 2rem;
    text-shadow: 1px 1px 2px rgba(0,0,0,0.2);
}
.search-box {
    position: relative;
    margin-bottom: 2.5rem;
}
input {
    width: 100%;
    padding: 16px 24px;
    border-radius: 28px;
    border: 2px solid #ffffff;
    background: rgba(255, 255, 255, 0.9);
    color: #000000;
    font-size: 1rem;
    outline: none;
    transition: all 0.3s ease;
}
input:focus {
    border-color: #4a90e2;
    box-shadow: 0 0 20px rgba(74, 144, 226, 0.3);
    transform: translateY(-2px);
}
input::placeholder { color: #666666; }
.buttons-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
    gap: 12px;
    margin-bottom: 2rem;
}
.custom-btn {
    padding: 14px 20px;
    border-radius: 12px;
    background: rgba(255, 255, 255, 0.95);
    border: 2px solid #ffffff;
    color: #000000;
    text-decoration: none;
    text-align: center;
    font-weight: 500;
    cursor: pointer;
    transition: all 0.3s ease;
    display: flex;
    align-items: center;
    justify-content: center;
    min-height: 52px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.1);
}
.custom-btn:hover {
    background: #ffffff;
    border-color: #4a90e2;
    transform: translateY(-3px);
    box-shadow: 0 6px 20px rgba(74, 144, 226, 0.3);
}
.custom-btn.type-js { color: #e67e22; border-color: #e67e22; }
.custom-btn.type-css { color: #e91e63; border-color: #e91e63; }
.custom-btn.type-html { color: #4caf50; border-color: #4caf50; }
footer {
    position: fixed;
    bottom: 20px;
    color: #ffffff;
    font-size: 0.85rem;
    text-align: center;
    text-shadow: 1px 1px 2px rgba(0,0,0,0.3);
}
.features {
    display: flex;
    justify-content: center;
    gap: 20px;
    margin-top: 1rem;
    flex-wrap: wrap;
}
.feature {
    color: #ffffff;
    font-size: 0.8rem;
    padding: 6px 12px;
    background: rgba(255, 255, 255, 0.2);
    border-radius: 6px;
    backdrop-filter: blur(10px);
}
</style>
</head>
<body>
<div class="container">
    <h1>🔥 FireSeed</h1>
    <div class="version">Version 6.2 (Enhanced) • Portable Edition with Advanced Plugins</div>
    
    <div class="search-box">
        <input id="q" type="text" placeholder="🔍 Search or enter URL..." 
               onkeypress="if(event.key==='Enter'){location.href='https://www.google.com/search?q='+encodeURIComponent(this.value)}">
    </div>
    
    <div class="buttons-grid" id="customButtons">
        <!-- Buttons will be injected here -->
    </div>
    
    <div class="features">
        <span class="feature">⚡ Modern Web Support</span>
        <span class="feature">🎨 Custom Buttons</span>
        <span class="feature">📱 Split Panel</span>
        <span class="feature">🔌 Advanced Plugins</span>
        <span class="feature">💾 Portable</span>
    </div>
</div>

<footer>© 2024 FireSeed Browser • Built with ❤️ • All data saved locally</footer>

<script>
const CUSTOM_BUTTONS = {{BUTTONS_JSON}};

function renderButtons() {
    const container = document.getElementById('customButtons');
    container.innerHTML = '';
    
    CUSTOM_BUTTONS.forEach(btn => {
        const element = document.createElement(btn.type === 'url' ? 'a' : 'button');
        element.className = `custom-btn type-${btn.type}`;
        element.textContent = btn.title;
        
        if (btn.type === 'url') {
            element.href = btn.value;
        } else if (btn.type === 'js') {
            element.onclick = () => eval(btn.value);
        } else if (btn.type === 'css') {
            element.onclick = () => {
                const style = document.createElement('style');
                style.textContent = btn.value;
                document.head.appendChild(style);
            };
        } else if (btn.type === 'html') {
            element.onclick = () => {
                const div = document.createElement('div');
                div.innerHTML = btn.value;
                document.body.appendChild(div);
            };
        }
        
        container.appendChild(element);
    });
}

renderButtons();
document.getElementById('q').focus();
</script>
</body>
</html>
"""

# ---------- JSON helpers ----------
def load_json(path: Path, default):
    try:
        if path.exists():
            return json.loads(path.read_text(encoding='utf-8'))
    except Exception:
        pass
    return default

def save_json(path: Path, data):
    try:
        path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding='utf-8')
    except Exception:
        pass

# ---------- Utilities ----------
def make_safe_js_string(s: str) -> str:
    return json.dumps(s, ensure_ascii=False)

def ensure_http_like(txt: str) -> str:
    txt = txt.strip()
    if not txt:
        return txt
    if txt.startswith(("http://", "https://", "file://", "about:")):
        return txt
    if " " not in txt and "." in txt and not txt.endswith("."):
        return "https://" + txt
    return "https://www.google.com/search?q=" + quote_plus(txt)

# ---------- User CSS injection ----------
def install_user_css(profile: QWebEngineProfile, css: str, name: str = "fireseed_user_css"):
    scripts = profile.scripts()
    try:
        names = list(scripts.scriptNames())
    except Exception:
        names = []
    for s_name in names:
        try:
            if s_name == name:
                found = scripts.findScript(s_name)
                if found:
                    scripts.remove(found)
        except Exception:
            pass
    
    js = f"""
(function(){{
  try {{
    var css = {make_safe_js_string(css)};
    var id = 'fireseed62-usercss';
    var existing = document.getElementById(id);
    if (existing) existing.remove();
    var style = document.createElement('style');
    style.id = id;
    style.type = 'text/css';
    style.appendChild(document.createTextNode(css));
    (document.head || document.documentElement).appendChild(style);
  }} catch(e) {{ console.error('usercss inject', e); }}
}})();
"""
    script = QWebEngineScript()
    script.setName(name)
    script.setSourceCode(js)
    script.setInjectionPoint(QWebEngineScript.DocumentCreation)
    script.setRunsOnSubFrames(True)
    try:
        script.setWorldId(QWebEngineScript.MainWorld)
    except Exception:
        pass
    try:
        scripts.insert(script)
    except Exception:
        pass

def install_user_css_from_file(profile: QWebEngineProfile):
    css = DEFAULT_USER_CSS
    try:
        if Path(USERCSS_FILE).exists():
            css = Path(USERCSS_FILE).read_text(encoding='utf-8')
    except Exception:
        pass
    install_user_css(profile, css, name="fireseed_user_css")

# ---------- Plugin Permissions System ----------
class PluginPermissions:
    """Manages plugin permissions"""
    FILE_SYSTEM = "file_system"
    NETWORK = "network"
    EXECUTE_CODE = "execute_code"
    SYSTEM_CONTROL = "system_control"
    BROWSER_CONTROL = "browser_control"
    USER_DATA = "user_data"
    
    ALL_PERMISSIONS = [
        FILE_SYSTEM,
        NETWORK,
        EXECUTE_CODE,
        SYSTEM_CONTROL,
        BROWSER_CONTROL,
        USER_DATA
    ]
    
    PERMISSION_DESCRIPTIONS = {
        FILE_SYSTEM: "Read and write files on your computer",
        NETWORK: "Access network and internet",
        EXECUTE_CODE: "Execute code and scripts",
        SYSTEM_CONTROL: "Control system functions (dangerous)",
        BROWSER_CONTROL: "Full control over browser",
        USER_DATA: "Access your browsing data and history"
    }

class PermissionManager:
    """Manages plugin permissions"""
    def __init__(self):
        self.permissions = load_json(PERMISSIONS_FILE, {})
    
    def request_permissions(self, plugin_name: str, permissions: list, parent=None) -> bool:
        """Request permissions for a plugin with user confirmation"""
        if plugin_name in self.permissions:
            # Check if all requested permissions are already granted
            granted = self.permissions[plugin_name].get("granted", [])
            if all(p in granted for p in permissions):
                return True
        
        # Show permission request dialog
        dlg = PermissionRequestDialog(plugin_name, permissions, parent)
        if dlg.exec_() == QDialog.Accepted:
            self.permissions[plugin_name] = {
                "granted": permissions,
                "timestamp": datetime.now().isoformat()
            }
            save_json(PERMISSIONS_FILE, self.permissions)
            return True
        return False
    
    def has_permission(self, plugin_name: str, permission: str) -> bool:
        """Check if plugin has a specific permission"""
        if plugin_name not in self.permissions:
            return False
        return permission in self.permissions[plugin_name].get("granted", [])
    
    def revoke_permissions(self, plugin_name: str):
        """Revoke all permissions for a plugin"""
        if plugin_name in self.permissions:
            del self.permissions[plugin_name]
            save_json(PERMISSIONS_FILE, self.permissions)

class PermissionRequestDialog(QDialog):
    """Dialog for requesting plugin permissions"""
    def __init__(self, plugin_name: str, permissions: list, parent=None):
        super().__init__(parent)
        self.setWindowTitle(f"⚠️ Permission Request - {plugin_name}")
        self.resize(500, 400)
        
        layout = QVBoxLayout(self)
        
        # Warning header
        warning = QLabel("🔒 SECURITY WARNING")
        warning.setFont(QFont("Arial", 14, QFont.Bold))
        warning.setStyleSheet("color: #e74c3c; padding: 10px;")
        warning.setAlignment(Qt.AlignCenter)
        layout.addWidget(warning)
        
        # Plugin name
        plugin_label = QLabel(f"Plugin '{plugin_name}' is requesting permissions to:")
        plugin_label.setFont(QFont("Arial", 11, QFont.Bold))
        plugin_label.setWordWrap(True)
        layout.addWidget(plugin_label)
        
        # Permissions list
        perm_widget = QWidget()
        perm_layout = QVBoxLayout(perm_widget)
        
        for perm in permissions:
            desc = PluginPermissions.PERMISSION_DESCRIPTIONS.get(perm, perm)
            
            perm_frame = QFrame()
            perm_frame.setStyleSheet("""
                QFrame {
                    background-color: #fff3cd;
                    border: 2px solid #ffc107;
                    border-radius: 6px;
                    padding: 8px;
                    margin: 4px;
                }
            """)
            
            perm_item_layout = QVBoxLayout(perm_frame)
            title = QLabel(f"⚠️ {perm.replace('_', ' ').title()}")
            title.setFont(QFont("Arial", 10, QFont.Bold))
            title.setStyleSheet("color: #856404;")
            
            description = QLabel(desc)
            description.setWordWrap(True)
            description.setStyleSheet("color: #856404;")
            
            perm_item_layout.addWidget(title)
            perm_item_layout.addWidget(description)
            
            perm_layout.addWidget(perm_frame)
        
        layout.addWidget(perm_widget)
        
        # Warning message
        warning_msg = QLabel(
            "⚠️ IMPORTANT: This plugin will have FULL CONTROL over the listed areas. "
            "Only allow permissions if you trust this plugin and its developer. "
            "Malicious plugins can harm your computer or steal your data!"
        )
        warning_msg.setWordWrap(True)
        warning_msg.setStyleSheet("""
            QLabel {
                background-color: #f8d7da;
                color: #721c24;
                padding: 12px;
                border: 2px solid #f5c6cb;
                border-radius: 6px;
                font-weight: bold;
            }
        """)
        layout.addWidget(warning_msg)
        
        # Buttons
        btn_layout = QHBoxLayout()
        deny_btn = QPushButton("🚫 Deny (Recommended)")
        deny_btn.setStyleSheet("""
            QPushButton {
                background-color: #6c757d;
                color: white;
                padding: 10px 20px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #5a6268;
            }
        """)
        
        allow_btn = QPushButton("✓ Allow (I trust this plugin)")
        allow_btn.setStyleSheet("""
            QPushButton {
                background-color: #28a745;
                color: white;
                padding: 10px 20px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #218838;
            }
        """)
        
        btn_layout.addWidget(deny_btn)
        btn_layout.addWidget(allow_btn)
        layout.addLayout(btn_layout)
        
        deny_btn.clicked.connect(self.reject)
        allow_btn.clicked.connect(self.accept)

# ---------- Enhanced Plugin API ----------
class PluginAPI:
    """Enhanced API provided to plugins with permission checking"""
    def __init__(self, browser_app, plugin_name: str):
        self.browser = browser_app
        self.plugin_name = plugin_name
        self.permission_manager = browser_app.permission_manager
    
    def _check_permission(self, permission: str) -> bool:
        """Check if plugin has permission"""
        if not self.permission_manager.has_permission(self.plugin_name, permission):
            QMessageBox.warning(
                self.browser,
                "Permission Denied",
                f"Plugin '{self.plugin_name}' does not have '{permission}' permission."
            )
            return False
        return True
    
    # Browser control methods
    def get_current_tab(self):
        """Get current browser tab"""
        if not self._check_permission(PluginPermissions.BROWSER_CONTROL):
            return None
        return self.browser.current_tab()
    
    def get_current_url(self):
        """Get URL of current tab"""
        if not self._check_permission(PluginPermissions.BROWSER_CONTROL):
            return ""
        tab = self.get_current_tab()
        return tab.web.url().toString() if tab else ""
    
    def execute_javascript(self, code):
        """Execute JavaScript in current tab"""
        if not self._check_permission(PluginPermissions.EXECUTE_CODE):
            return
        tab = self.get_current_tab()
        if tab:
            tab.web.page().runJavaScript(code)
    
    def inject_css(self, css):
        """Inject CSS into current tab"""
        if not self._check_permission(PluginPermissions.BROWSER_CONTROL):
            return
        js = f"""
        var style = document.createElement('style');
        style.textContent = {make_safe_js_string(css)};
        document.head.appendChild(style);
        """
        self.execute_javascript(js)
    
    def create_tab(self, url='about:home'):
        """Create new tab"""
        if not self._check_permission(PluginPermissions.BROWSER_CONTROL):
            return None
        return self.browser._add_tab(url)
    
    def show_message(self, title, message):
        """Show message box"""
        QMessageBox.information(self.browser, title, message)
    
    def add_toolbar_button(self, text, callback, icon=None):
        """Add button to plugin toolbar"""
        if not self._check_permission(PluginPermissions.BROWSER_CONTROL):
            return None
        action = QAction(text, self.browser)
        if icon:
            action.setIcon(icon)
        action.triggered.connect(callback)
        self.browser.plugin_toolbar.addAction(action)
        return action
    
    def add_homepage_button(self, title, type, value):
        """Add button to homepage"""
        if not self._check_permission(PluginPermissions.BROWSER_CONTROL):
            return False
        button_data = {"title": title, "type": type, "value": value}
        self.browser.custom_buttons.append(button_data)
        save_json(BUTTONS_FILE, self.browser.custom_buttons)
        return True
    
    def add_menu_action(self, menu_name, text, callback):
        """Add action to menu"""
        if not self._check_permission(PluginPermissions.BROWSER_CONTROL):
            return None
        if menu_name not in self.browser.plugin_menus:
            self.browser.plugin_menus[menu_name] = self.browser.menuBar().addMenu(menu_name)
        action = QAction(text, self.browser)
        action.triggered.connect(callback)
        self.browser.plugin_menus[menu_name].addAction(action)
        return action
    
    def get_panel_widget(self):
        """Get reference to Tools panel for adding custom tabs"""
        if not self._check_permission(PluginPermissions.BROWSER_CONTROL):
            return None
        if self.browser.tools_panel:
            return self.browser.tools_panel.panel_tabs
        return None
    
    # File system methods
    def read_file(self, filepath):
        """Read file from disk"""
        if not self._check_permission(PluginPermissions.FILE_SYSTEM):
            return None
        try:
            return Path(filepath).read_text(encoding='utf-8')
        except Exception as e:
            QMessageBox.warning(self.browser, "File Error", f"Failed to read file: {e}")
            return None
    
    def write_file(self, filepath, content):
        """Write file to disk"""
        if not self._check_permission(PluginPermissions.FILE_SYSTEM):
            return False
        try:
            Path(filepath).write_text(content, encoding='utf-8')
            return True
        except Exception as e:
            QMessageBox.warning(self.browser, "File Error", f"Failed to write file: {e}")
            return False
    
    # User data methods
    def get_bookmarks(self):
        """Get user bookmarks"""
        if not self._check_permission(PluginPermissions.USER_DATA):
            return []
        return self.browser.bookmarks.copy()
    
    def add_bookmark(self, title, url):
        """Add bookmark"""
        if not self._check_permission(PluginPermissions.USER_DATA):
            return False
        self.browser.bookmarks.append({"title": title, "url": url})
        save_json(BOOKMARKS_FILE, self.browser.bookmarks)
        self.browser._refresh_bookmarks_toolbar()
        return True
    
    def get_history(self):
        """Get browsing history"""
        if not self._check_permission(PluginPermissions.USER_DATA):
            return []
        return self.browser.history.copy()
    
    # System control methods
    def execute_system_command(self, command):
        """Execute system command (requires system_control permission)"""
        if not self._check_permission(PluginPermissions.SYSTEM_CONTROL):
            return None
        try:
            import subprocess
            result = subprocess.run(command, shell=True, capture_output=True, text=True)
            return {"stdout": result.stdout, "stderr": result.stderr, "returncode": result.returncode}
        except Exception as e:
            return {"error": str(e)}

class Plugin:
    """Base class for plugins"""
    def __init__(self, api: PluginAPI):
        self.api = api
        self.name = "Base Plugin"
        self.version = "1.0"
        self.description = "A FireSeed plugin"
        self.required_permissions = []  # List of required permissions
    
    def activate(self):
        """Called when plugin is activated"""
        pass
    
    def deactivate(self):
        """Called when plugin is deactivated"""
        pass

# ---------- Plugin Manager ----------
class PluginManager:
    def __init__(self, browser_app):
        self.browser = browser_app
        self.plugins = {}
        self.active_plugins = set()
        self.load_plugins_config()
    
    def load_plugins_config(self):
        """Load which plugins are enabled"""
        config = load_json(PLUGINS_CONFIG, {})
        self.active_plugins = set(config.get("active", []))
    
    def save_plugins_config(self):
        """Save which plugins are enabled"""
        save_json(PLUGINS_CONFIG, {"active": list(self.active_plugins)})
    
    def discover_plugins(self):
        """Discover all plugins in plugins directory"""
        for item in PLUGINS_DIR.iterdir():
            if item.is_file() and item.suffix == '.py' and not item.name.startswith('_'):
                self.load_plugin(item)
    
    def load_plugin(self, plugin_path: Path):
        """Load a single plugin"""
        try:
            spec = importlib.util.spec_from_file_location(plugin_path.stem, plugin_path)
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
            
            if hasattr(module, 'PluginClass'):
                # Create API for this plugin
                api = PluginAPI(self.browser, plugin_path.stem)
                plugin_instance = module.PluginClass(api)
                
                self.plugins[plugin_path.stem] = {
                    'instance': plugin_instance,
                    'path': plugin_path,
                    'module': module
                }
                
                # Don't auto-activate - require user permission first
                return True
        except Exception as e:
            print(f"Failed to load plugin {plugin_path.name}: {e}")
            return False
    
    def activate_plugin(self, plugin_name):
        """Activate a plugin with permission check"""
        if plugin_name in self.plugins:
            try:
                plugin_instance = self.plugins[plugin_name]['instance']
                
                # Request permissions if needed
                if plugin_instance.required_permissions:
                    if not self.browser.permission_manager.request_permissions(
                        plugin_name,
                        plugin_instance.required_permissions,
                        self.browser
                    ):
                        return False
                
                plugin_instance.activate()
                self.active_plugins.add(plugin_name)
                self.save_plugins_config()
                return True
            except Exception as e:
                print(f"Failed to activate plugin {plugin_name}: {e}")
                QMessageBox.warning(
                    self.browser,
                    "Plugin Error",
                    f"Failed to activate plugin {plugin_name}:\n{e}"
                )
        return False
    
    def deactivate_plugin(self, plugin_name):
        """Deactivate a plugin"""
        if plugin_name in self.plugins:
            try:
                self.plugins[plugin_name]['instance'].deactivate()
                self.active_plugins.discard(plugin_name)
                self.save_plugins_config()
                return True
            except Exception as e:
                print(f"Failed to deactivate plugin {plugin_name}: {e}")
        return False
    
    def reload_plugin(self, plugin_name):
        """Reload a plugin"""
        if plugin_name in self.plugins:
            plugin_data = self.plugins[plugin_name]
            was_active = plugin_name in self.active_plugins
            
            if was_active:
                self.deactivate_plugin(plugin_name)
            
            self.load_plugin(plugin_data['path'])
            
            if was_active:
                self.activate_plugin(plugin_name)

# ---------- Code Editor with Syntax Highlighting ----------
class PythonHighlighter(QSyntaxHighlighter):
    def __init__(self, parent=None):
        super().__init__(parent)
        
        # Define formats
        keyword_format = QTextCharFormat()
        keyword_format.setForeground(QColor("#ff79c6"))
        keyword_format.setFontWeight(QFont.Bold)
        
        string_format = QTextCharFormat()
        string_format.setForeground(QColor("#f1fa8c"))
        
        comment_format = QTextCharFormat()
        comment_format.setForeground(QColor("#6272a4"))
        
        function_format = QTextCharFormat()
        function_format.setForeground(QColor("#50fa7b"))
        
        # Keywords
        keywords = [
            'False', 'None', 'True', 'and', 'as', 'assert', 'async', 'await',
            'break', 'class', 'continue', 'def', 'del', 'elif', 'else', 'except',
            'finally', 'for', 'from', 'global', 'if', 'import', 'in', 'is',
            'lambda', 'nonlocal', 'not', 'or', 'pass', 'raise', 'return',
            'try', 'while', 'with', 'yield'
        ]
        
        self.highlighting_rules = []
        
        for keyword in keywords:
            pattern = f'\\b{keyword}\\b'
            self.highlighting_rules.append((pattern, keyword_format))
        
        self.highlighting_rules.append((r'"[^"\\]*(\\.[^"\\]*)*"', string_format))
        self.highlighting_rules.append((r"'[^'\\]*(\\.[^'\\]*)*'", string_format))
        self.highlighting_rules.append((r'#[^\n]*', comment_format))
        self.highlighting_rules.append((r'\bdef\s+(\w+)', function_format))
    
    def highlightBlock(self, text):
        import re
        for pattern, fmt in self.highlighting_rules:
            for match in re.finditer(pattern, text):
                self.setFormat(match.start(), match.end() - match.start(), fmt)

class CodeEditor(QTextEdit):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFont(QFont("Consolas", 11))
        self.setTabStopDistance(40)
        self.highlighter = PythonHighlighter(self.document())
        
        # Set dark theme
        self.setStyleSheet("""
            QTextEdit {
                background-color: #282a36;
                color: #f8f8f2;
                border: 1px solid #44475a;
                border-radius: 4px;
                padding: 8px;
            }
        """)
    
    def keyPressEvent(self, event):
        # Auto-indent on Enter
        if event.key() == Qt.Key_Return or event.key() == Qt.Key_Enter:
            cursor = self.textCursor()
            block = cursor.block().text()
            indent = len(block) - len(block.lstrip())
            
            super().keyPressEvent(event)
            
            if block.rstrip().endswith(':'):
                indent += 4
            
            self.insertPlainText(' ' * indent)
            return
        
        # Tab handling
        if event.key() == Qt.Key_Tab:
            self.insertPlainText('    ')
            return
        
        super().keyPressEvent(event)

# ---------- Browser Tab ----------
class BrowserTab(QWidget):
    def __init__(self, url='about:home', parent_app=None):
        super().__init__()
        self.parent_app = parent_app
        self.layout = QVBoxLayout(self)
        self.layout.setContentsMargins(0,0,0,0)
        self.web = QWebEngineView()
        
        # Enable modern web features
        settings = self.web.settings()
        settings.setAttribute(QWebEngineSettings.JavascriptEnabled, True)
        settings.setAttribute(QWebEngineSettings.JavascriptCanOpenWindows, True)
        settings.setAttribute(QWebEngineSettings.LocalStorageEnabled, True)
        settings.setAttribute(QWebEngineSettings.PluginsEnabled, True)
        settings.setAttribute(QWebEngineSettings.FullScreenSupportEnabled, True)
        settings.setAttribute(QWebEngineSettings.WebGLEnabled, True)
        settings.setAttribute(QWebEngineSettings.Accelerated2dCanvasEnabled, True)
        
        self.layout.addWidget(self.web)
        self.setLayout(self.layout)
        
        try:
            self.web.page().profile().setHttpAcceptLanguage('en-US,en;q=0.9')
        except Exception:
            pass
        
        try:
            install_user_css_from_file(self.web.page().profile())
        except Exception:
            pass
        
        self.load_url(url)

    def load_url(self, url):
        if url == 'about:home':
            buttons = load_json(BUTTONS_FILE, DEFAULT_BUTTONS)
            homepage = HOMEPAGE_HTML.replace('{{BUTTONS_JSON}}', json.dumps(buttons))
            self.web.setHtml(homepage, QUrl('about:home'))
        else:
            self.web.load(QUrl(url))

# ---------- Tools Panel Widget ----------
class ToolsPanel(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumWidth(350)
        self.setMaximumWidth(600)
        
        layout = QVBoxLayout(self)
        layout.setContentsMargins(10, 10, 10, 10)
        
        # Header
        header = QHBoxLayout()
        title = QLabel("🛠️ Tools Panel")
        title.setFont(QFont("Arial", 12, QFont.Bold))
        header.addWidget(title)
        header.addStretch()
        
        close_btn = QPushButton("✕")
        close_btn.setMaximumWidth(30)
        close_btn.clicked.connect(self.close_panel)
        header.addWidget(close_btn)
        layout.addLayout(header)
        
        # Tabs for different functions
        self.panel_tabs = QTabWidget()
        
        # Tools tab
        tools_widget = QWidget()
        tools_layout = QVBoxLayout(tools_widget)
        
        # JavaScript executor
        tools_layout.addWidget(QLabel("Execute JavaScript:"))
        self.js_input = QTextEdit()
        self.js_input.setPlaceholderText("Enter JavaScript code...")
        self.js_input.setMaximumHeight(100)
        tools_layout.addWidget(self.js_input)
        
        js_btn = QPushButton("▶ Run JS (Ctrl+Enter)")
        js_btn.clicked.connect(self.run_panel_js)
        tools_layout.addWidget(js_btn)
        
        # CSS injector
        tools_layout.addWidget(QLabel("Inject CSS:"))
        self.css_input = QTextEdit()
        self.css_input.setPlaceholderText("Enter CSS code...")
        self.css_input.setMaximumHeight(100)
        tools_layout.addWidget(self.css_input)
        
        css_btn = QPushButton("🎨 Apply CSS (Ctrl+Shift+Enter)")
        css_btn.clicked.connect(self.inject_panel_css)
        tools_layout.addWidget(css_btn)
        
        tools_layout.addStretch()
        self.panel_tabs.addTab(tools_widget, "🛠️ Tools")
        
        # Code Editor tab
        editor_widget = QWidget()
        editor_layout = QVBoxLayout(editor_widget)
        
        editor_layout.addWidget(QLabel("In-Browser Python Editor:"))
        self.code_editor = CodeEditor()
        self.code_editor.setPlaceholderText("# Write Python code here...\n# Ctrl+S to save\n# Ctrl+R to run")
        editor_layout.addWidget(self.code_editor)
        
        editor_btn_layout = QHBoxLayout()
        save_btn = QPushButton("💾 Save (Ctrl+S)")
        save_btn.clicked.connect(self.save_code)
        run_btn = QPushButton("▶ Run (Ctrl+R)")
        run_btn.clicked.connect(self.run_code)
        load_btn = QPushButton("📂 Load")
        load_btn.clicked.connect(self.load_code)
        editor_btn_layout.addWidget(save_btn)
        editor_btn_layout.addWidget(run_btn)
        editor_btn_layout.addWidget(load_btn)
        editor_layout.addLayout(editor_btn_layout)
        
        self.code_output = QTextEdit()
        self.code_output.setReadOnly(True)
        self.code_output.setPlaceholderText("Output appears here...")
        self.code_output.setMaximumHeight(100)
        editor_layout.addWidget(QLabel("Output:"))
        editor_layout.addWidget(self.code_output)
        
        self.panel_tabs.addTab(editor_widget, "💻 Code Editor")
        
        # Notes tab
        notes_widget = QWidget()
        notes_layout = QVBoxLayout(notes_widget)
        self.notes_area = QTextEdit()
        self.notes_area.setPlaceholderText("Take notes here...")
        notes_layout.addWidget(self.notes_area)
        self.panel_tabs.addTab(notes_widget, "📝 Notes")
        
        layout.addWidget(self.panel_tabs)
        
        # Keyboard shortcuts
        self.setup_shortcuts()
        
        # Styling
        self.setStyleSheet("""
            QWidget {
                background-color: #1a1f2e;
                color: #ffffff;
            }
            QTabWidget::pane {
                border: 1px solid #2a3f5f;
                border-radius: 4px;
            }
            QTabBar::tab {
                background: #243447;
                color: #ffffff;
                padding: 8px 16px;
                border: 1px solid #2a3f5f;
                border-bottom: none;
                border-top-left-radius: 4px;
                border-top-right-radius: 4px;
            }
            QTabBar::tab:selected {
                background: #2a3f5f;
                color: #4a90e2;
            }
            QTextEdit, QLineEdit {
                background-color: #0a0e1a;
                border: 1px solid #2a3f5f;
                border-radius: 4px;
                padding: 6px;
                color: #ffffff;
            }
            QPushButton {
                background-color: #243447;
                color: #4a90e2;
                border: 1px solid #2a3f5f;
                border-radius: 4px;
                padding: 6px 12px;
            }
            QPushButton:hover {
                background-color: #2a3f5f;
                border-color: #4a90e2;
            }
            QLabel {
                color: #ffffff;
            }
        """)
    
    def setup_shortcuts(self):
        """Setup keyboard shortcuts for panel"""
        QShortcut(QKeySequence("Ctrl+Return"), self, self.run_panel_js)
        QShortcut(QKeySequence("Ctrl+Shift+Return"), self, self.inject_panel_css)
        QShortcut(QKeySequence("Ctrl+S"), self, self.save_code)
        QShortcut(QKeySequence("Ctrl+R"), self, self.run_code)
    
    def close_panel(self):
        self.parent().toggle_tools_panel()
    
    def run_panel_js(self):
        js_code = self.js_input.toPlainText()
        if hasattr(self.parent(), 'current_tab'):
            tab = self.parent().current_tab()
            if tab:
                tab.web.page().runJavaScript(js_code)
    
    def inject_panel_css(self):
        css_code = self.css_input.toPlainText()
        if hasattr(self.parent(), 'current_tab'):
            tab = self.parent().current_tab()
            if tab:
                js = f"""
                    var style = document.createElement('style');
                    style.textContent = {make_safe_js_string(css_code)};
                    document.head.appendChild(style);
                """
                tab.web.page().runJavaScript(js)
    
    def save_code(self):
        """Save code to file"""
        code = self.code_editor.toPlainText()
        filename, _ = QFileDialog.getSaveFileName(self, "Save Code", str(PLUGINS_DIR), "Python Files (*.py)")
        if filename:
            try:
                Path(filename).write_text(code, encoding='utf-8')
                self.code_output.append(f"✓ Saved to {filename}")
            except Exception as e:
                self.code_output.append(f"✗ Error: {e}")
    
    def load_code(self):
        """Load code from file"""
        filename, _ = QFileDialog.getOpenFileName(self, "Load Code", str(PLUGINS_DIR), "Python Files (*.py)")
        if filename:
            try:
                code = Path(filename).read_text(encoding='utf-8')
                self.code_editor.setPlainText(code)
                self.code_output.append(f"✓ Loaded from {filename}")
            except Exception as e:
                self.code_output.append(f"✗ Error: {e}")
    
    def run_code(self):
        """Run Python code (limited execution)"""
        code = self.code_editor.toPlainText()
        self.code_output.clear()
        
        try:
            # Create a limited namespace for execution
            namespace = {
                '__builtins__': __builtins__,
                'print': lambda *args: self.code_output.append(' '.join(map(str, args)))
            }
            
            exec(code, namespace)
            if not self.code_output.toPlainText():
                self.code_output.append("✓ Code executed successfully (no output)")
        except Exception as e:
            self.code_output.append(f"✗ Error: {e}")

# ---------- Main App ----------
class BrowserApp(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle(f"{APP_NAME} - {APP_VERSION} - Portable")
        self.resize(1400, 900)

        # Storage
        self.bookmarks = load_json(BOOKMARKS_FILE, [])
        self.session = load_json(SESSION_FILE, {})
        self.custom_buttons = load_json(BUTTONS_FILE, DEFAULT_BUTTONS)
        self.history = load_json(HISTORY_FILE, [])
        self.settings = load_json(SETTINGS_FILE, {})
        
        self.tools_panel = None
        self.panel_visible = False
        self.plugin_menus = {}

        # Permission system
        self.permission_manager = PermissionManager()
        
        # Plugin system
        self.plugin_manager = PluginManager(self)

        self._build_ui()
        self._restore_session()
        
        # Load plugins
        self.plugin_manager.discover_plugins()
        
        # Show data location on startup
        self.statusBar().showMessage(f"💾 Data saved in: {DATA_DIR}", 5000)

    def _build_ui(self):
        # Main splitter for browser and panel
        self.main_splitter = QSplitter(Qt.Horizontal)
        
        # Browser area
        browser_widget = QWidget()
        browser_layout = QVBoxLayout(browser_widget)
        browser_layout.setContentsMargins(0, 0, 0, 0)
        
        # Tabs
        self.tabs = QTabWidget()
        self.tabs.setTabsClosable(True)
        self.tabs.tabCloseRequested.connect(self._close_tab)
        self.tabs.currentChanged.connect(self._on_tab_changed)
        browser_layout.addWidget(self.tabs)
        
        self.main_splitter.addWidget(browser_widget)
        self.setCentralWidget(self.main_splitter)

        # Navigation toolbar
        nav = QToolBar('Navigation')
        nav.setIconSize(QSize(20, 20))
        nav.setMovable(False)
        self.addToolBar(nav)

        self.back_act = QAction('◀', self)
        self.back_act.triggered.connect(lambda: self.current_tab().web.back() if self.current_tab() else None)
        
        self.forward_act = QAction('▶', self)
        self.forward_act.triggered.connect(lambda: self.current_tab().web.forward() if self.current_tab() else None)
        
        self.reload_act = QAction('⟳', self)
        self.reload_act.triggered.connect(lambda: self.current_tab().web.reload() if self.current_tab() else None)
        
        self.home_act = QAction('🏠', self)
        self.home_act.triggered.connect(lambda: self.current_tab().load_url('about:home') if self.current_tab() else None)
        
        self.newtab_act = QAction('+', self)
        self.newtab_act.triggered.connect(lambda: self._add_tab())

        self.addr = QLineEdit(self)
        self.addr.returnPressed.connect(self._on_enter_address)
        self.addr.setPlaceholderText("Search or enter address...")

        nav.addAction(self.back_act)
        nav.addAction(self.forward_act)
        nav.addAction(self.reload_act)
        nav.addAction(self.home_act)
        nav.addAction(self.newtab_act)
        nav.addWidget(self.addr)

        # Tools panel toggle
        panel_act = QAction('🛠️ Panel', self)
        panel_act.triggered.connect(self.toggle_tools_panel)
        nav.addAction(panel_act)

        # Plugin toolbar (for plugins to add actions)
        self.plugin_toolbar = QToolBar('Plugins')
        self.plugin_toolbar.setMovable(False)
        self.addToolBar(self.plugin_toolbar)

        # Menu bar
        menubar = self.menuBar()
        
        # File menu
        file_menu = menubar.addMenu('File')
        file_menu.addAction('New Tab', lambda: self._add_tab(), 'Ctrl+T')
        file_menu.addAction('Close Tab', lambda: self._close_tab(self.tabs.currentIndex()), 'Ctrl+W')
        file_menu.addSeparator()
        file_menu.addAction('Open Data Folder', self.open_data_folder)
        file_menu.addSeparator()
        file_menu.addAction('Exit', self.close, 'Ctrl+Q')
        
        # View menu
        view_menu = menubar.addMenu('View')
        view_menu.addAction('Toggle Panel', self.toggle_tools_panel, 'Ctrl+P')
        view_menu.addAction('Toggle Console', self.toggle_console, 'F12')
        view_menu.addAction('Full Screen', self.toggle_fullscreen, 'F11')
        view_menu.addSeparator()
        view_menu.addAction('View History', self.view_history)
        
        # Tools menu
        tools_menu = menubar.addMenu('Tools')
        tools_menu.addAction('Manage Bookmarks', self.manage_bookmarks, 'Ctrl+B')
        tools_menu.addAction('Custom Buttons', self.manage_custom_buttons, 'Ctrl+M')
        tools_menu.addAction('User CSS', self.edit_user_css)
        tools_menu.addSeparator()
        tools_menu.addAction('Clear History', self.clear_history)
        tools_menu.addAction('Export History', self.export_history)
        
        # Plugins menu
        plugins_menu = menubar.addMenu('Plugins')
        plugins_menu.addAction('Manage Plugins', self.manage_plugins)
        plugins_menu.addAction('Manage Permissions', self.manage_permissions)
        plugins_menu.addAction('Open Plugins Folder', self.open_plugins_folder)
        plugins_menu.addSeparator()

        # Bookmarks toolbar
        self.bookmarks_toolbar = QToolBar('Bookmarks')
        self.bookmarks_toolbar.setMovable(False)
        self.addToolBar(self.bookmarks_toolbar)
        self._refresh_bookmarks_toolbar()

        # Console dock (hidden by default)
        self.console = QDockWidget('Developer Console', self)
        console_widget = QWidget()
        console_layout = QVBoxLayout(console_widget)
        
        self.console_tabs = QTabWidget()
        
        # JavaScript tab
        js_widget = QWidget()
        js_layout = QVBoxLayout(js_widget)
        self.js_edit = QTextEdit()
        self.js_edit.setPlaceholderText("Enter JavaScript code here...")
        js_layout.addWidget(self.js_edit)
        js_btn = QPushButton("Run JavaScript")
        js_btn.clicked.connect(self.run_js)
        js_layout.addWidget(js_btn)
        self.console_tabs.addTab(js_widget, "JavaScript")
        
        # CSS tab
        css_widget = QWidget()
        css_layout = QVBoxLayout(css_widget)
        self.css_edit = QTextEdit()
        self.css_edit.setPlaceholderText("Enter CSS code here...")
        css_layout.addWidget(self.css_edit)
        css_buttons = QHBoxLayout()
        css_inject_btn = QPushButton("Inject CSS")
        css_inject_btn.clicked.connect(self.inject_css)
        css_save_btn = QPushButton("Save & Apply")
        css_save_btn.clicked.connect(self.save_user_css)
        css_buttons.addWidget(css_inject_btn)
        css_buttons.addWidget(css_save_btn)
        css_layout.addLayout(css_buttons)
        self.console_tabs.addTab(css_widget, "CSS")
        
        console_layout.addWidget(self.console_tabs)
        self.console.setWidget(console_widget)
        self.addDockWidget(Qt.BottomDockWidgetArea, self.console)
        self.console.hide()

        # Downloads dock
        self.downloads_dock = QDockWidget('Downloads', self)
        self.downloads_list = QListWidget()
        self.downloads_dock.setWidget(self.downloads_list)
        self.addDockWidget(Qt.BottomDockWidgetArea, self.downloads_dock)
        self.downloads_dock.hide()

        # Initial tab
        if self.tabs.count() == 0:
            self._add_tab()

        # Apply white theme
        self.setStyleSheet("""
            QMainWindow {
                background-color: #f5f5f5;
            }
            QToolBar {
                background-color: #ffffff;
                border: none;
                padding: 4px;
                spacing: 6px;
                color: #000000;
            }
            QToolBar QLabel {
                color: #000000;
            }
            QToolBar::separator {
                background-color: #e0e0e0;
                width: 1px;
                margin: 4px;
            }
            QLineEdit {
                background-color: #ffffff;
                color: #000000;
                border: 1px solid #cccccc;
                border-radius: 16px;
                padding: 6px 16px;
                font-size: 13px;
            }
            QLineEdit:focus {
                border-color: #4a90e2;
            }
            QTabWidget::pane {
                border: none;
                background-color: #ffffff;
            }
            QTabBar::tab {
                background: #f0f0f0;
                color: #000000;
                padding: 8px 16px;
                border: 1px solid #e0e0e0;
                border-bottom: none;
                min-width: 120px;
            }
            QTabBar::tab:selected {
                background: #ffffff;
                color: #4a90e2;
            }
            QTabBar::tab:hover {
                background: #e8e8e8;
            }
            QPushButton {
                background-color: #4a90e2;
                color: #ffffff;
                border: 1px solid #4a90e2;
                border-radius: 4px;
                padding: 6px 12px;
            }
            QPushButton:hover {
                background-color: #357abd;
                border-color: #357abd;
            }
            QMenuBar {
                background-color: #ffffff;
                color: #000000;
            }
            QMenuBar::item:selected {
                background-color: #e8e8e8;
            }
            QMenu {
                background-color: #ffffff;
                color: #000000;
                border: 1px solid #cccccc;
            }
            QMenu::item:selected {
                background-color: #e8e8e8;
            }
            QStatusBar {
                background-color: #ffffff;
                color: #666666;
            }
        """)

    # ---------- Data Folder Management ----------
    def open_data_folder(self):
        """Open data folder in file manager"""
        import subprocess
        import platform
        
        if platform.system() == 'Windows':
            os.startfile(DATA_DIR)
        elif platform.system() == 'Darwin':  # macOS
            subprocess.Popen(['open', DATA_DIR])
        else:  # Linux
            subprocess.Popen(['xdg-open', DATA_DIR])

    # ---------- History Management ----------
    def view_history(self):
        """View browsing history"""
        dlg = QDialog(self)
        dlg.setWindowTitle("Browsing History")
        dlg.resize(600, 400)
        layout = QVBoxLayout(dlg)

        # History list
        list_widget = QListWidget()
        for entry in reversed(self.history[-100:]):  # Show last 100 entries
            timestamp = entry.get('timestamp', 'Unknown')
            title = entry.get('title', 'Untitled')
            url = entry.get('url', '')
            item = QListWidgetItem(f"[{timestamp}] {title}\n{url}")
            item.setData(Qt.UserRole, url)
            list_widget.addItem(item)
        
        layout.addWidget(QLabel(f"Total history entries: {len(self.history)}"))
        layout.addWidget(list_widget)

        # Buttons
        btn_layout = QHBoxLayout()
        open_btn = QPushButton("Open Selected")
        clear_btn = QPushButton("Clear All")
        export_btn = QPushButton("Export")
        close_btn = QPushButton("Close")
        
        btn_layout.addWidget(open_btn)
        btn_layout.addWidget(clear_btn)
        btn_layout.addWidget(export_btn)
        btn_layout.addStretch()
        btn_layout.addWidget(close_btn)
        layout.addLayout(btn_layout)

        def open_selected():
            selected = list_widget.currentItem()
            if selected:
                url = selected.data(Qt.UserRole)
                self._add_tab(url)
                dlg.close()

        def clear_all():
            reply = QMessageBox.question(dlg, 'Clear History', 
                                       'Are you sure you want to clear all history?',
                                       QMessageBox.Yes | QMessageBox.No)
            if reply == QMessageBox.Yes:
                self.history = []
                save_json(HISTORY_FILE, self.history)
                list_widget.clear()
                QMessageBox.information(dlg, 'Success', 'History cleared!')

        open_btn.clicked.connect(open_selected)
        clear_btn.clicked.connect(clear_all)
        export_btn.clicked.connect(lambda: self.export_history(dlg))
        close_btn.clicked.connect(dlg.accept)

        dlg.exec_()

    def clear_history(self):
        """Clear browsing history"""
        reply = QMessageBox.question(self, 'Clear History', 
                                     'Are you sure you want to clear browsing history?',
                                     QMessageBox.Yes | QMessageBox.No)
        if reply == QMessageBox.Yes:
            self.history = []
            save_json(HISTORY_FILE, self.history)
            QMessageBox.information(self, 'Success', 'History cleared!')

    def export_history(self, parent=None):
        """Export history to file"""
        if not parent:
            parent = self
        
        filename, _ = QFileDialog.getSaveFileName(
            parent,
            "Export History",
            str(DATA_DIR / f"history_export_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"),
            "JSON Files (*.json);;Text Files (*.txt)"
        )
        
        if filename:
            try:
                if filename.endswith('.json'):
                    save_json(Path(filename), self.history)
                else:
                    # Export as text
                    with open(filename, 'w', encoding='utf-8') as f:
                        for entry in self.history:
                            f.write(f"[{entry.get('timestamp')}] {entry.get('title')}\n")
                            f.write(f"  {entry.get('url')}\n\n")
                
                QMessageBox.information(parent, 'Success', f'History exported to:\n{filename}')
            except Exception as e:
                QMessageBox.warning(parent, 'Error', f'Failed to export history:\n{e}')

    # ---------- Permission Management ----------
    def manage_permissions(self):
        """Manage plugin permissions"""
        dlg = QDialog(self)
        dlg.setWindowTitle("Plugin Permissions Manager")
        dlg.resize(700, 500)
        layout = QVBoxLayout(dlg)

        # Info
        info = QLabel("🔒 Manage which permissions plugins have. Revoke permissions to restrict plugin access.")
        info.setWordWrap(True)
        info.setStyleSheet("padding: 10px; background-color: #fff3cd; border: 1px solid #ffc107; border-radius: 4px;")
        layout.addWidget(info)

        # Permissions list
        list_widget = QListWidget()
        for plugin_name, perm_data in self.permission_manager.permissions.items():
            granted = perm_data.get("granted", [])
            timestamp = perm_data.get("timestamp", "Unknown")
            
            perm_text = ", ".join([p.replace("_", " ").title() for p in granted])
            item = QListWidgetItem(f"🔌 {plugin_name}\n   Permissions: {perm_text}\n   Granted: {timestamp}")
            item.setData(Qt.UserRole, plugin_name)
            list_widget.addItem(item)
        
        layout.addWidget(QLabel("Plugins with Permissions:"))
        layout.addWidget(list_widget)

        # Buttons
        btn_layout = QHBoxLayout()
        revoke_btn = QPushButton("🚫 Revoke Permissions")
        close_btn = QPushButton("Close")
        
        btn_layout.addWidget(revoke_btn)
        btn_layout.addStretch()
        btn_layout.addWidget(close_btn)
        layout.addLayout(btn_layout)

        def revoke_permissions():
            selected = list_widget.currentItem()
            if selected:
                plugin_name = selected.data(Qt.UserRole)
                reply = QMessageBox.question(
                    dlg,
                    'Revoke Permissions',
                    f'Are you sure you want to revoke all permissions for "{plugin_name}"?\n\n'
                    'The plugin will be deactivated and will need to request permissions again.',
                    QMessageBox.Yes | QMessageBox.No
                )
                if reply == QMessageBox.Yes:
                    # Deactivate plugin
                    self.plugin_manager.deactivate_plugin(plugin_name)
                    # Revoke permissions
                    self.permission_manager.revoke_permissions(plugin_name)
                    # Remove from list
                    list_widget.takeItem(list_widget.currentRow())
                    QMessageBox.information(dlg, 'Success', f'Permissions revoked for {plugin_name}')

        revoke_btn.clicked.connect(revoke_permissions)
        close_btn.clicked.connect(dlg.accept)

        dlg.exec_()

    # ---------- Plugin Management ----------
    def manage_plugins(self):
        """Show plugin management dialog"""
        dlg = QDialog(self)
        dlg.setWindowTitle("Plugin Manager")
        dlg.resize(700, 500)
        layout = QVBoxLayout(dlg)

        # Info label
        info = QLabel(f"📁 Plugins folder: {PLUGINS_DIR}\n\n"
                     "⚠️ Only install plugins from trusted sources! Plugins have extensive permissions.")
        info.setWordWrap(True)
        info.setStyleSheet("padding: 10px; background-color: #f8d7da; border: 1px solid #f5c6cb; border-radius: 4px;")
        layout.addWidget(info)

        # Plugin list
        list_widget = QListWidget()
        for plugin_name, plugin_data in self.plugin_manager.plugins.items():
            plugin = plugin_data['instance']
            status = "✅ Active" if plugin_name in self.plugin_manager.active_plugins else "⭕ Inactive"
            
            perms = ", ".join([p.replace("_", " ").title() for p in plugin.required_permissions]) if plugin.required_permissions else "None"
            
            item = QListWidgetItem(
                f"{status} | {plugin.name} v{plugin.version}\n"
                f"   {plugin.description}\n"
                f"   Required Permissions: {perms}"
            )
            item.setData(Qt.UserRole, plugin_name)
            list_widget.addItem(item)
        
        layout.addWidget(QLabel("Installed Plugins:"))
        layout.addWidget(list_widget)

        # Buttons
        btn_layout = QHBoxLayout()
        toggle_btn = QPushButton("Toggle Active")
        reload_btn = QPushButton("Reload")
        open_folder_btn = QPushButton("Open Folder")
        close_btn = QPushButton("Close")
        
        btn_layout.addWidget(toggle_btn)
        btn_layout.addWidget(reload_btn)
        btn_layout.addWidget(open_folder_btn)
        btn_layout.addStretch()
        btn_layout.addWidget(close_btn)
        layout.addLayout(btn_layout)

        def toggle_plugin():
            selected = list_widget.currentItem()
            if selected:
                plugin_name = selected.data(Qt.UserRole)
                if plugin_name in self.plugin_manager.active_plugins:
                    if self.plugin_manager.deactivate_plugin(plugin_name):
                        selected.setText(selected.text().replace("✅ Active", "⭕ Inactive"))
                        QMessageBox.information(dlg, "Success", f"Plugin {plugin_name} deactivated!")
                else:
                    if self.plugin_manager.activate_plugin(plugin_name):
                        selected.setText(selected.text().replace("⭕ Inactive", "✅ Active"))
                        QMessageBox.information(dlg, "Success", f"Plugin {plugin_name} activated!")

        def reload_plugin():
            selected = list_widget.currentItem()
            if selected:
                plugin_name = selected.data(Qt.UserRole)
                self.plugin_manager.reload_plugin(plugin_name)
                QMessageBox.information(dlg, "Success", f"Plugin {plugin_name} reloaded!")

        toggle_btn.clicked.connect(toggle_plugin)
        reload_btn.clicked.connect(reload_plugin)
        open_folder_btn.clicked.connect(self.open_plugins_folder)
        close_btn.clicked.connect(dlg.accept)

        dlg.exec_()

    def open_plugins_folder(self):
        """Open plugins folder in file manager"""
        import subprocess
        import platform
        
        if platform.system() == 'Windows':
            os.startfile(PLUGINS_DIR)
        elif platform.system() == 'Darwin':  # macOS
            subprocess.Popen(['open', PLUGINS_DIR])
        else:  # Linux
            subprocess.Popen(['xdg-open', PLUGINS_DIR])

    # ---------- Panel and UI Methods ----------
    def toggle_tools_panel(self):
        if not self.tools_panel:
            self.tools_panel = ToolsPanel(self)
            self.main_splitter.addWidget(self.tools_panel)
            self.main_splitter.setSizes([1000, 400])
            self.panel_visible = True
        else:
            if self.panel_visible:
                self.tools_panel.hide()
                self.panel_visible = False
            else:
                self.tools_panel.show()
                self.panel_visible = True

    def toggle_console(self):
        self.console.setVisible(not self.console.isVisible())

    def toggle_fullscreen(self):
        if self.isFullScreen():
            self.showNormal()
        else:
            self.showFullScreen()

    def manage_custom_buttons(self):
        dlg = QDialog(self)
        dlg.setWindowTitle("Custom Homepage Buttons")
        dlg.resize(600, 450)
        layout = QVBoxLayout(dlg)

        list_widget = QListWidget()
        for btn in self.custom_buttons:
            item = QListWidgetItem(f"[{btn['type'].upper()}] {btn['title']}")
            list_widget.addItem(item)
        layout.addWidget(list_widget)

        btn_layout = QHBoxLayout()
        add_btn = QPushButton("➕ Add Button")
        edit_btn = QPushButton("✏️ Edit Selected")
        delete_btn = QPushButton("🗑️ Delete Selected")
        close_btn = QPushButton("Close")
        
        btn_layout.addWidget(add_btn)
        btn_layout.addWidget(edit_btn)
        btn_layout.addWidget(delete_btn)
        btn_layout.addStretch()
        btn_layout.addWidget(close_btn)
        layout.addLayout(btn_layout)

        def add_button():
            editor = ButtonEditorDialog(self)
            if editor.exec_() == QDialog.Accepted:
                btn_data = editor.get_button_data()
                self.custom_buttons.append(btn_data)
                save_json(BUTTONS_FILE, self.custom_buttons)
                list_widget.addItem(f"[{btn_data['type'].upper()}] {btn_data['title']}")

        def edit_button():
            selected = list_widget.currentRow()
            if selected >= 0:
                editor = ButtonEditorDialog(self, self.custom_buttons[selected])
                if editor.exec_() == QDialog.Accepted:
                    btn_data = editor.get_button_data()
                    self.custom_buttons[selected] = btn_data
                    save_json(BUTTONS_FILE, self.custom_buttons)
                    list_widget.currentItem().setText(f"[{btn_data['type'].upper()}] {btn_data['title']}")

        def delete_button():
            selected = list_widget.currentRow()
            if selected >= 0:
                del self.custom_buttons[selected]
                save_json(BUTTONS_FILE, self.custom_buttons)
                list_widget.takeItem(selected)

        add_btn.clicked.connect(add_button)
        edit_btn.clicked.connect(edit_button)
        delete_btn.clicked.connect(delete_button)
        close_btn.clicked.connect(dlg.accept)

        dlg.exec_()

    def edit_user_css(self):
        dlg = QDialog(self)
        dlg.setWindowTitle("Edit User CSS")
        dlg.resize(600, 400)
        layout = QVBoxLayout(dlg)

        edit = QTextEdit()
        try:
            if USERCSS_FILE.exists():
                edit.setPlainText(USERCSS_FILE.read_text(encoding='utf-8'))
            else:
                edit.setPlainText(DEFAULT_USER_CSS)
        except Exception:
            edit.setPlainText(DEFAULT_USER_CSS)
        
        layout.addWidget(QLabel("Edit your global user CSS:"))
        layout.addWidget(edit)

        btn_layout = QHBoxLayout()
        save_btn = QPushButton("Save & Apply")
        close_btn = QPushButton("Close")
        btn_layout.addWidget(save_btn)
        btn_layout.addWidget(close_btn)
        layout.addLayout(btn_layout)

        def save_css():
            try:
                USERCSS_FILE.write_text(edit.toPlainText(), encoding='utf-8')
                install_user_css(QWebEngineProfile.defaultProfile(), edit.toPlainText())
                for i in range(self.tabs.count()):
                    t = self.tabs.widget(i)
                    install_user_css(t.web.page().profile(), edit.toPlainText())
                    t.web.reload()
                QMessageBox.information(dlg, "Success", "CSS saved and applied!")
            except Exception as e:
                QMessageBox.warning(dlg, "Error", f"Failed to save CSS: {e}")

        save_btn.clicked.connect(save_css)
        close_btn.clicked.connect(dlg.accept)

        dlg.exec_()

    def save_user_css(self):
        css = self.css_edit.toPlainText()
        try:
            USERCSS_FILE.write_text(css, encoding='utf-8')
            install_user_css(QWebEngineProfile.defaultProfile(), css)
            for i in range(self.tabs.count()):
                t = self.tabs.widget(i)
                install_user_css(t.web.page().profile(), css)
                t.web.reload()
        except Exception:
            QMessageBox.warning(self, "CSS Save", "Failed to save or inject CSS.")

    def run_js(self):
        js = self.js_edit.toPlainText()
        tab = self.current_tab()
        if tab:
            try:
                tab.web.page().runJavaScript(js)
            except Exception:
                pass

    def inject_css(self):
        css = self.css_edit.toPlainText()
        try:
            install_user_css(QWebEngineProfile.defaultProfile(), css, name="user_css_dynamic")
            for i in range(self.tabs.count()):
                t = self.tabs.widget(i)
                try:
                    install_user_css(t.web.page().profile(), css, name="user_css_dynamic")
                    t.web.reload()
                except Exception:
                    pass
        except Exception:
            pass

    # ---------- Tab & UI helpers ----------
    def _add_tab(self, url='about:home'):
        tab = BrowserTab(url, self)
        idx = self.tabs.addTab(tab, "New Tab")
        self.tabs.setCurrentIndex(idx)

        page = tab.web.page()
        page.urlChanged.connect(lambda qurl, t=tab: self._on_url_changed(t, qurl))
        page.loadFinished.connect(lambda ok, t=tab: self._on_load_finished(t, ok))
        page.titleChanged.connect(lambda title, t=tab: self.update_tab_title_from_tab(t, title))
        page.iconChanged.connect(lambda icon, t=tab: self.update_tab_favicon(t, icon))
        
        try:
            page.profile().downloadRequested.connect(self._on_download_requested)
        except Exception:
            pass

        return tab

    def _close_tab(self, idx):
        if self.tabs.count() > 1:
            self.tabs.removeTab(idx)
        else:
            self.close()

    def current_tab(self) -> typing.Optional[BrowserTab]:
        return self.tabs.currentWidget()

    def _on_tab_changed(self, idx):
        tab = self.current_tab()
        if not tab:
            return
        url = tab.web.url().toString()
        self.addr.setText(url or "")
        try:
            self.back_act.setEnabled(tab.web.history().canGoBack())
            self.forward_act.setEnabled(tab.web.history().canGoForward())
        except Exception:
            pass

    def _on_url_changed(self, tab: BrowserTab, qurl: QUrl):
        if self.tabs.indexOf(tab) == self.tabs.currentIndex():
            self.addr.setText(qurl.toString())

    def _on_load_finished(self, tab: BrowserTab, ok: bool):
        url = tab.web.url().toString()
        title = tab.web.title() or url
        idx = self.tabs.indexOf(tab)
        if idx >= 0:
            display = title if len(title) <= 30 else title[:27] + "..."
            self.tabs.setTabText(idx, display)
        
        # Add to history with timestamp
        history_entry = {
            "title": title,
            "url": url,
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }
        self.history.append(history_entry)
        
        # Save history periodically (every 10 entries)
        if len(self.history) % 10 == 0:
            save_json(HISTORY_FILE, self.history)

    def update_tab_title_from_tab(self, tab: BrowserTab, title: str):
        idx = self.tabs.indexOf(tab)
        if idx >= 0:
            display = title if len(title) <= 30 else title[:27] + "..."
            self.tabs.setTabText(idx, display)
            if idx == self.tabs.currentIndex():
                self.addr.setText(tab.web.url().toString())

    def update_tab_favicon(self, tab: BrowserTab, icon):
        idx = self.tabs.indexOf(tab)
        if idx >= 0 and not icon.isNull():
            self.tabs.setTabIcon(idx, icon)

    def _on_enter_address(self):
        txt = self.addr.text().strip()
        if not txt:
            return
        target = ensure_http_like(txt)
        tab = self.current_tab()
        if tab:
            tab.load_url(target)

    # ---------- Bookmarks ----------
    def _refresh_bookmarks_toolbar(self):
        self.bookmarks_toolbar.clear()
        for bm in self.bookmarks:
            act = QAction(bm.get("title", bm.get("url")), self)
            act.setToolTip(bm.get("url"))
            act.triggered.connect(lambda checked=False, u=bm.get("url"): 
                                self.current_tab().load_url(u) if self.current_tab() else None)
            self.bookmarks_toolbar.addAction(act)
        manage = QAction("⭐ Manage", self)
        manage.triggered.connect(self.manage_bookmarks)
        self.bookmarks_toolbar.addAction(manage)

    def manage_bookmarks(self):
        dlg = QDialog(self)
        dlg.setWindowTitle("Bookmarks Manager")
        dlg.resize(500, 350)
        layout = QVBoxLayout(dlg)

        list_widget = QListWidget()
        for bm in self.bookmarks:
            item = QListWidgetItem(f"{bm.get('title', bm.get('url'))} — {bm.get('url')}")
            list_widget.addItem(item)
        layout.addWidget(list_widget)

        btn_layout = QHBoxLayout()
        add_btn = QPushButton("Add Current")
        delete_btn = QPushButton("Delete Selected")
        export_btn = QPushButton("Export")
        close_btn = QPushButton("Close")
        btn_layout.addWidget(add_btn)
        btn_layout.addWidget(delete_btn)
        btn_layout.addWidget(export_btn)
        btn_layout.addWidget(close_btn)
        layout.addLayout(btn_layout)

        def export_bookmarks():
            filename, _ = QFileDialog.getSaveFileName(
                dlg,
                "Export Bookmarks",
                str(DATA_DIR / "bookmarks_export.json"),
                "JSON Files (*.json);;HTML Files (*.html)"
            )
            if filename:
                try:
                    if filename.endswith('.html'):
                        # Export as HTML bookmark file
                        html = '<!DOCTYPE NETSCAPE-Bookmark-file-1>\n<HTML>\n<HEAD>\n<TITLE>Bookmarks</TITLE>\n</HEAD>\n<BODY>\n<H1>Bookmarks</H1>\n<DL><p>\n'
                        for bm in self.bookmarks:
                            html += f'<DT><A HREF="{bm.get("url")}">{bm.get("title", bm.get("url"))}</A>\n'
                        html += '</DL></p>\n</BODY>\n</HTML>'
                        Path(filename).write_text(html, encoding='utf-8')
                    else:
                        save_json(Path(filename), self.bookmarks)
                    QMessageBox.information(dlg, "Success", f"Bookmarks exported to:\n{filename}")
                except Exception as e:
                    QMessageBox.warning(dlg, "Error", f"Failed to export:\n{e}")

        add_btn.clicked.connect(lambda: self._add_current_bookmark(list_widget))
        delete_btn.clicked.connect(lambda: self._delete_selected_bookmark(list_widget))
        export_btn.clicked.connect(export_bookmarks)
        close_btn.clicked.connect(dlg.accept)

        dlg.exec_()

    def _add_current_bookmark(self, list_widget):
        tab = self.current_tab()
        if tab:
            url = tab.web.url().toString()
            title = tab.web.title() or url
            self.bookmarks.append({"title": title, "url": url})
            save_json(BOOKMARKS_FILE, self.bookmarks)
            self._refresh_bookmarks_toolbar()
            list_widget.addItem(f"{title} — {url}")

    def _delete_selected_bookmark(self, list_widget):
        selected = list_widget.currentRow()
        if selected >= 0:
            del self.bookmarks[selected]
            save_json(BOOKMARKS_FILE, self.bookmarks)
            list_widget.takeItem(selected)
            self._refresh_bookmarks_toolbar()

    # ---------- Downloads ----------
    def _on_download_requested(self, download: QWebEngineDownloadItem):
        # Default to downloads folder
        default_path = DOWNLOADS_DIR / (download.downloadFileName() or "download")
        suggested = QFileDialog.getSaveFileName(self, "Save File", str(default_path))[0]
        
        if not suggested:
            download.cancel()
            return
        download.setPath(suggested)
        download.accept()
        item = QListWidgetItem(f"Downloading: {QFileInfo(suggested).fileName()}")
        self.downloads_list.addItem(item)
        self.downloads_dock.setVisible(True)
        download.finished.connect(lambda: item.setText(f"Completed: {QFileInfo(suggested).fileName()}"))

    # ---------- Session persistence ----------
    def _restore_session(self):
        saved = load_json(SESSION_FILE, {})
        tabs = saved.get("tabs", [])
        if tabs:
            try:
                while self.tabs.count():
                    self.tabs.removeTab(0)
            except Exception:
                pass
            for turl in tabs:
                self._add_tab(turl)

    def closeEvent(self, event):
        # Save session
        tabs = []
        for i in range(self.tabs.count()):
            tab = self.tabs.widget(i)
            u = tab.web.url().toString()
            tabs.append(u or "about:home")
        save_json(SESSION_FILE, {"tabs": tabs})
        
        # Save all data
        save_json(BOOKMARKS_FILE, self.bookmarks)
        save_json(BUTTONS_FILE, self.custom_buttons)
        save_json(HISTORY_FILE, self.history)
        save_json(SETTINGS_FILE, self.settings)
        
        super().closeEvent(event)

# ---------- Button Editor Dialog ----------
class ButtonEditorDialog(QDialog):
    def __init__(self, parent=None, button_data=None):
        super().__init__(parent)
        self.setWindowTitle("Edit Button")
        self.resize(500, 300)
        
        layout = QVBoxLayout(self)
        
        layout.addWidget(QLabel("Button Title:"))
        self.title_input = QLineEdit()
        if button_data:
            self.title_input.setText(button_data.get('title', ''))
        layout.addWidget(self.title_input)
        
        layout.addWidget(QLabel("Button Type:"))
        self.type_combo = QComboBox()
        self.type_combo.addItems(['url', 'js', 'css', 'html'])
        if button_data:
            idx = self.type_combo.findText(button_data.get('type', 'url'))
            if idx >= 0:
                self.type_combo.setCurrentIndex(idx)
        layout.addWidget(self.type_combo)
        
        layout.addWidget(QLabel("Value (URL or Code):"))
        self.value_input = QTextEdit()
        if button_data:
            self.value_input.setPlainText(button_data.get('value', ''))
        layout.addWidget(self.value_input)
        
        btn_layout = QHBoxLayout()
        save_btn = QPushButton("Save")
        cancel_btn = QPushButton("Cancel")
        btn_layout.addWidget(save_btn)
        btn_layout.addWidget(cancel_btn)
        layout.addLayout(btn_layout)
        
        save_btn.clicked.connect(self.accept)
        cancel_btn.clicked.connect(self.reject)
    
    def get_button_data(self):
        return {
            'title': self.title_input.text(),
            'type': self.type_combo.currentText(),
            'value': self.value_input.toPlainText()
        }

# ---------- Entry point ----------
def main():
    try:
        print("Starting FireSeed browser...")
        
        app = QApplication(sys.argv)
        app.setApplicationName(APP_NAME)
        app.setApplicationVersion(APP_VERSION)
        
        print("Checking WebEngine...")
        try:
            _ = QWebEngineProfile()
        except Exception as e:
            QMessageBox.critical(None, "Missing Components", 
                               f"PyQtWebEngine error: {e}\n\nInstall with:\n\npip install PyQt5 PyQtWebEngine")
            return
        
        print("Initializing data files...")
        # Initialize files
        if not BUTTONS_FILE.exists():
            save_json(BUTTONS_FILE, DEFAULT_BUTTONS)
        if not PLUGINS_CONFIG.exists():
            save_json(PLUGINS_CONFIG, {"active": []})
        if not HISTORY_FILE.exists():
            save_json(HISTORY_FILE, [])
        if not SETTINGS_FILE.exists():
            save_json(SETTINGS_FILE, {})
        if not PERMISSIONS_FILE.exists():
            save_json(PERMISSIONS_FILE, {})
        
        # Show startup info
        print(f"🔥 FireSeed {APP_VERSION} - Enhanced Portable Edition")
        print(f"📁 Data directory: {DATA_DIR}")
        print(f"🔌 Plugins directory: {PLUGINS_DIR}")
        print(f"📥 Downloads directory: {DOWNLOADS_DIR}")
        print(f"📜 History saved to: {HISTORY_FILE}")
        print(f"🔒 Permissions saved to: {PERMISSIONS_FILE}")
        print("")
        
        print("Creating browser window...")
        w = BrowserApp()
        
        print("Showing window...")
        w.show()
        
        print("Browser started successfully!")
        print("=" * 60)
        
        sys.exit(app.exec_())
        
    except Exception as e:
        import traceback
        error_msg = f"""
{'=' * 60}
FATAL ERROR - FireSeed crashed on startup
{'=' * 60}

Error Type: {type(e).__name__}
Error Message: {str(e)}

Full Traceback:
{traceback.format_exc()}

{'=' * 60}
Please report this error with the above information.
{'=' * 60}
"""
        print(error_msg)
        
        # Try to show error dialog if possible
        try:
            app = QApplication.instance()
            if app is None:
                app = QApplication(sys.argv)
            QMessageBox.critical(None, "FireSeed Crash", 
                               f"FireSeed crashed on startup:\n\n{type(e).__name__}: {str(e)}\n\nCheck console for details.")
        except:
            pass
        
        input("\nPress Enter to exit...")

if __name__ == '__main__':
    main()